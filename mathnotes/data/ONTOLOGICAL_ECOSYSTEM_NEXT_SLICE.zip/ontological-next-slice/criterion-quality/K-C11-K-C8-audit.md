# Criterion-quality queue: K-C11 then K-C8

Status: offline audit and proposed replacement criteria. Not yet applied to the live Perchance constraint registry. Source criteria are retained verbatim below for traceability.

## K-C11 — infeasible as currently worded

**Original:** “A verification audit confirms that 100% of failure states are reconstructible from the 512-byte identity entries via the MMR root without data loss.”

**Quality verdict:** `INFEASIBLE_AS_STATED`.

**Why:** an MMR/Merkle root is a commitment to a structure, not a storage or reconstruction channel for payloads that are absent. A fixed 512-byte record may carry identifiers, digests, and pointers, but it cannot by itself guarantee lossless reconstruction of arbitrary failure-state payloads. “100%” is also undefined without a closed population of committed entries and a retrieval boundary. The 512-byte test-scenario constraint should remain labeled `test_scenario`; do not promote it into a deployment fact without separate evidence.

### Replacement: three independent obligations

1. **Integrity:** Every committed entry included in the declared test interval is checked against its committed digest; a modified payload or proof must be detected and rejected. Test by flipping bytes in a selected committed record while preserving the expected commitment.
2. **Availability:** Every committed entry in the test interval has a declared retrieval locator and is retrievable from the designated durable store. Removal or unavailability must produce `UNAVAILABLE/FAIL`, never `VERIFIED`. Test by removing one referenced payload while leaving the commitment in place.
3. **Completeness / continuity:** Every committed sequence number between explicitly anchored start and end checkpoints is present, or each gap is reported. Use append-only sequence identifiers and a checkpoint whose expected value is held outside the mutable dataset under test. Test by deleting or skipping a middle entry and require a gap/inconsistency verdict.

**Scope:** the finite test interval and the set of entries explicitly recorded as committed before the test. Do not say “arbitrary complexity,” “all possible failures,” or “reconstructible from the root alone.”

**Pass rule:** all three obligations pass independently. No averaging and no single aggregate “100% provenance” value may hide an unavailable payload or undetected gap.

## K-C8 — requires a bounded retention contract

**Original:** “The storage medium's write-count remains below the hardware threshold while the Cold-Start Auditor can still reconstruct the full genomic chain via the aggregated Merkle proofs.”

**Quality verdict:** `UNDERSPECIFIED` until the storage device, rated write budget, workload, retention horizon, durable-store location, and definition of “full genomic chain” are provided.

**Replacement obligations:**

1. **Write-budget compliance:** identify the device and manufacturer-specified write metric; run a fixed, versioned workload; record writes before/after; remain below the declared budget with the safety margin defined in advance.
2. **Durable retrieval:** each committed lineage payload has a durable locator and can be restored in a cold-start test; a Merkle path authenticates retrieved data but is not substituted for missing payloads.
3. **Retention and continuity:** declare the retention horizon and expected chain boundaries. Verify that every payload within that horizon can be retrieved and that missing/overwritten entries are represented by explicit tombstones or produce a failed completeness check.

Do not promise indefinite retention on finite storage. If archival data is offloaded, the archive's availability and trust model become explicit dependencies rather than presumed properties.

## Gatekeeping rule

The criterion-quality layer evaluates criteria and routes defects; it does not certify its own corrections. The correction becomes accepted only after a separate test harness executes the stated perturbations and stores raw outcomes. Status progression:

`UNASSESSED → REWRITTEN → TESTED → EXTERNALLY/INDEPENDENTLY VERIFIED`

Rewriting a criterion alone advances only to `REWRITTEN`.
