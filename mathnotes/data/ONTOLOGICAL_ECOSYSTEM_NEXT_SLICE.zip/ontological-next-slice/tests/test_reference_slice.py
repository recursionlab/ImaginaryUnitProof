import json
import sys
import unittest
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "congruence"))
from gate import gate
import importlib.util

def load_module(module_name, path):
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

evaluate_governor = load_module("governor_evaluate", ROOT / "governor-fire-drill" / "evaluate.py").evaluate
evaluate_p2 = load_module("p2_evaluate", ROOT / "p2-acceptance" / "evaluate.py").evaluate

class ReferenceSliceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixtures = json.loads((ROOT / "congruence" / "fixtures.json").read_text(encoding="utf-8"))

    def test_explicit_relevant_plan_aligns(self):
        result = gate(self.fixtures["aligned"]).as_dict()
        self.assertEqual(result["verdict"], "aligned")
        self.assertEqual(result["objectivesWithMappedActions"], 1)
        self.assertEqual(result["unrelatedOrUnsupportedActions"], 0)
        self.assertEqual(result["missingFields"], 0)

    def test_cycle24_legacy_plan_is_rejected_as_misaligned(self):
        result = gate(self.fixtures["cycle24_legacy_drift"]).as_dict()
        self.assertEqual(result["verdict"], "misaligned")
        self.assertEqual(result["objectivesWithMappedActions"], 0)
        self.assertEqual(result["unrelatedOrUnsupportedActions"], 4)

    def test_missing_acceptance_test_cannot_pass(self):
        result = gate(self.fixtures["missing_acceptance_test"]).as_dict()
        self.assertEqual(result["verdict"], "partially_aligned")
        self.assertGreater(result["missingFields"], 0)
        self.assertIn("traceability_fields_missing", result["reasons"])

    def test_known_but_wrong_obligation_does_not_count_as_mapping(self):
        result = gate(self.fixtures["wrong_obligation_for_target"]).as_dict()
        self.assertEqual(result["verdict"], "misaligned")
        self.assertEqual(result["objectivesWithMappedActions"], 0)
        self.assertEqual(result["unrelatedOrUnsupportedActions"], 1)

    def test_mrmd_relation_does_not_assert_identity(self):
        rel = json.loads((ROOT / "mrmd" / "relations" / "rel-001.json").read_text(encoding="utf-8"))
        self.assertEqual(rel["status"], "candidate")
        self.assertIn("The two domains are not asserted to be mathematically identical.", rel["nonClaims"])

    def test_governor_fire_drill_requires_regrounding_objective_and_artifacts(self):
        fixtures = json.loads((ROOT / "governor-fire-drill" / "fixtures.json").read_text(encoding="utf-8"))
        passing = evaluate_governor(fixtures["synthetic_pass_example"])
        failing = evaluate_governor(fixtures["synthetic_drift_failure"])
        self.assertTrue(passing["pass"])
        self.assertFalse(failing["pass"])
        self.assertIn("declaredObjectivePreserved", failing["failedChecks"])
        self.assertIn("evidenceArtifactsRetained", failing["failedChecks"])

    def test_p2_requires_measured_divergence_and_cited_replacement(self):
        fixtures = json.loads((ROOT / "p2-acceptance" / "fixtures.json").read_text(encoding="utf-8"))
        passing = evaluate_p2(fixtures["synthetic_pass_example"])
        failing = evaluate_p2(fixtures["synthetic_failure_uncited"])
        self.assertTrue(passing["pass"])
        self.assertGreaterEqual(passing["jaccardDistance"], 0.20)
        self.assertFalse(failing["pass"])
        self.assertIn("replacementArtifactCited", failing["failedChecks"])
        self.assertIn("divergenceMeetsThreshold", failing["failedChecks"])

    def test_c11_and_c8_have_distinct_obligations(self):
        queue = json.loads((ROOT / "criterion-quality" / "queue.json").read_text(encoding="utf-8"))
        items = {x["id"]: x for x in queue["items"]}
        self.assertEqual(items["K-C11"]["replacementObligations"], ["integrity", "availability", "completeness_continuity"])
        self.assertIn("write_budget_compliance", items["K-C8"]["replacementObligations"])
        self.assertEqual(items["K-C11"]["status"], "REWRITTEN_NOT_APPLIED")

    def test_cairn_and_relation_records_validate_against_schema(self):
        cairn_schema = json.loads((ROOT / "mrmd" / "schemas" / "cairn.schema.json").read_text(encoding="utf-8"))
        relation_schema = json.loads((ROOT / "mrmd" / "schemas" / "relation.schema.json").read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(cairn_schema)
        Draft202012Validator.check_schema(relation_schema)
        for path in (ROOT / "mrmd" / "cairns").glob("*.json"):
            Draft202012Validator(cairn_schema).validate(json.loads(path.read_text(encoding="utf-8")))
        for path in (ROOT / "mrmd" / "relations").glob("*.json"):
            Draft202012Validator(relation_schema).validate(json.loads(path.read_text(encoding="utf-8")))

    def test_cairns_separate_representation_and_evidence_axes(self):
        for path in (ROOT / "mrmd" / "cairns").glob("*.json"):
            obj = json.loads(path.read_text(encoding="utf-8"))
            self.assertIn("representationMaturity", obj["epistemic"])
            self.assertIn("evidenceStrength", obj["epistemic"])
            self.assertIn("rawText", obj["anchor"])

if __name__ == "__main__":
    unittest.main(verbosity=2)
