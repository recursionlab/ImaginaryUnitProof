"""Deterministic evaluator for a retained Governor fire-drill trace."""
from typing import Any

THRESHOLD = 0.50
REQUIRED_ARTIFACTS = {"perturbation_trace", "congruence_report"}


def evaluate(trace: dict[str, Any]) -> dict[str, Any]:
    perturbed = trace.get("perturbedAbstraction")
    post = trace.get("postGroundingAbstraction")
    threshold_crossed = isinstance(perturbed, (int, float)) and perturbed > THRESHOLD
    regrounded = isinstance(post, (int, float)) and post <= THRESHOLD
    declared = trace.get("declaredObjectiveId")
    after = trace.get("postObjectiveId")
    objective_preserved = bool(declared) and declared == after
    aligned = trace.get("congruenceVerdict") == "aligned"
    retained = set(trace.get("retainedArtifacts", []))
    artifacts_retained = REQUIRED_ARTIFACTS.issubset(retained)
    checks = {
        "perturbationCrossedThreshold": threshold_crossed,
        "postPerturbationRegrounded": regrounded,
        "declaredObjectivePreserved": objective_preserved,
        "planCongruenceAligned": aligned,
        "evidenceArtifactsRetained": artifacts_retained,
    }
    return {
        "schemaVersion": "governor-fire-drill-result-1",
        "checks": checks,
        "pass": all(checks.values()),
        "failedChecks": [k for k, v in checks.items() if not v],
        "threshold": THRESHOLD,
        "evidenceBoundary": "evaluates supplied trace only; does not prove live execution or independent provenance",
    }
