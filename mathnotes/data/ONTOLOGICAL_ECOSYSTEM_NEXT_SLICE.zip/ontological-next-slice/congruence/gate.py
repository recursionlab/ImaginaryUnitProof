"""Small deterministic reference Plan–Execution Congruence Gate.

This is an offline reference harness, not the live Perchance implementation.
It deliberately checks explicit IDs and required artifacts, not semantic similarity.
"""
from dataclasses import dataclass, asdict
from typing import Any

OBJECTIVES = {
    "variation_selection",
    "criterion_quality",
    "governor_fire_drill",
    "correction_steering",
    "evidence_trait_pruning",
}
OBJECTIVE_OBLIGATIONS = {
    "variation_selection": {"variation_select_feedback"},
    "criterion_quality": {"criterion_testability_audit"},
    "governor_fire_drill": {"governor_threshold_perturbation"},
    "correction_steering": {"verdict_to_next_action"},
    "evidence_trait_pruning": {"trait_prune_with_retained_provenance"},
}
OBLIGATIONS = set().union(*OBJECTIVE_OBLIGATIONS.values())
REQUIRED = ("targetObjective", "targetObligation", "action", "artifact", "acceptanceTest", "failureModes")

@dataclass
class GateResult:
    declaredObjectives: int
    objectivesWithMappedActions: int
    steps: int
    actionsWithArtifacts: int
    actionsWithAcceptanceTests: int
    unrelatedOrUnsupportedActions: int
    missingFields: int
    verdict: str
    reasons: list[str]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def gate(plan: dict[str, Any]) -> GateResult:
    declared = set(plan.get("declaredObjectives", []))
    steps = plan.get("execution", [])
    mapped: set[str] = set()
    unrelated = 0
    missing_fields = 0
    artifact_count = 0
    test_count = 0
    reasons: list[str] = []

    for step in steps:
        for field in REQUIRED:
            val = step.get(field)
            if val is None or val == "" or (field == "failureModes" and not val):
                missing_fields += 1
        target = step.get("targetObjective")
        obligation = step.get("targetObligation")
        supported = (target in declared and target in OBJECTIVES and
                     obligation in OBJECTIVE_OBLIGATIONS.get(target, set()))
        if supported:
            mapped.add(target)
        else:
            unrelated += 1
        if step.get("artifact"):
            artifact_count += 1
        if step.get("acceptanceTest"):
            test_count += 1

    covered = len(mapped)
    if not steps:
        verdict = "misaligned"
        reasons.append("no_execution_steps")
    elif covered == 0 or unrelated == len(steps):
        verdict = "misaligned"
        reasons.append("no_supported_target_action_mapping")
    elif covered < len(declared) or unrelated > 0 or missing_fields > 0:
        verdict = "partially_aligned"
        if covered < len(declared): reasons.append("objective_coverage_gap")
        if unrelated > 0: reasons.append("unsupported_or_drifting_steps")
        if missing_fields > 0: reasons.append("traceability_fields_missing")
    else:
        verdict = "aligned"
    if not declared:
        verdict = "misaligned"
        reasons.append("no_declared_objectives")

    return GateResult(
        declaredObjectives=len(declared),
        objectivesWithMappedActions=covered,
        steps=len(steps),
        actionsWithArtifacts=artifact_count,
        actionsWithAcceptanceTests=test_count,
        unrelatedOrUnsupportedActions=unrelated,
        missingFields=missing_fields,
        verdict=verdict,
        reasons=reasons,
    )
