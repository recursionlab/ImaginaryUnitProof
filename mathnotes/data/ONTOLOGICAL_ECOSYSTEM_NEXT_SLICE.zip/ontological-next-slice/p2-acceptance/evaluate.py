"""Deterministic evaluator for a retained P2 acceptance record."""
from typing import Any

DEFAULT_MIN_DIVERGENCE = 0.20


def evaluate(record: dict[str, Any], min_divergence: float = DEFAULT_MIN_DIVERGENCE) -> dict[str, Any]:
    baseline = record.get("baselineActionIds")
    replacement = record.get("replacementActionIds")
    known_refs = record.get("knownArtifactRefs", [])
    ref = record.get("replacesArtifactRef")
    same_run_context = bool(record.get("seed")) and bool(record.get("inputDigest"))
    valid_sets = isinstance(baseline, list) and isinstance(replacement, list) and len(set(baseline)) > 0 and len(set(baseline) | set(replacement)) > 0
    if valid_sets:
        a, b = set(baseline), set(replacement)
        union = a | b
        divergence = len(a ^ b) / len(union)
    else:
        divergence = None
    cited = bool(ref) and ref in known_refs
    nonidentical = valid_sets and set(baseline) != set(replacement)
    checks = {
        "sameRunContextRetained": same_run_context,
        "actionSetsWellFormed": valid_sets,
        "divergenceMeetsThreshold": divergence is not None and divergence >= min_divergence,
        "replacementDiffers": nonidentical,
        "replacementArtifactCited": cited,
    }
    return {
        "schemaVersion": "p2-acceptance-result-1",
        "seed": record.get("seed"),
        "inputDigest": record.get("inputDigest"),
        "baselineCount": len(set(baseline)) if isinstance(baseline, list) else None,
        "replacementCount": len(set(replacement)) if isinstance(replacement, list) else None,
        "jaccardDistance": divergence,
        "minimumDivergence": min_divergence,
        "checks": checks,
        "pass": all(checks.values()),
        "failedChecks": [k for k, v in checks.items() if not v],
        "evidenceBoundary": "evaluates supplied run record only; usefulness and live model behavior need separate evidence",
    }
