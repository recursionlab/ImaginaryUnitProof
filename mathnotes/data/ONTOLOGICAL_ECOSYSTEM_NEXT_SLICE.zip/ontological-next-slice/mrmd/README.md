# Meta-Realized Meta-Cairn DropBox (MRMD)

MRMD is a persistence-and-re-entry layer for realizations, not a generator catalog. The initial records preserve the two supplied anchors and keep the cross-domain relation explicitly candidate-level.

- `inbox/`: reserved for raw captures; captures need not be understood to be preserved.
- `cairns/`: durable realization records.
- `meta-cairns/`: relations or patterns across multiple cairns.
- `relations/`: typed links with explicit warrant and non-claims.
- `evidence/`: test traces, derivations, and source commitments.
- `schemas/`: record contracts.
- `index/`: generated search and navigation only, never the canonical source.

## Non-forcing rules

1. Never replace an anchor with its interpretation.
2. Keep representation maturity separate from evidence strength.
3. Candidate analogy is not identity, derivation, or verification.
4. Preserve contradictory interpretations as separate claims with provenance.
5. Rewriting a formalization creates a successor record or explicit revision; historical records are not silently overwritten.
