# MRMD Index

This folder is generated/navigation space only. The canonical initial records are `cairns/cairn-001.json`, `cairns/cairn-002.json`, `relations/rel-001.json`, and `meta-cairns/mc-001.json`.

Relation state is `candidate`; do not upgrade it automatically because two records share vocabulary or sequence shape.
